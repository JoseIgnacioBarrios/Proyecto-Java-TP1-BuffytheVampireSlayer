package Logic.GameObjects;

public class Player {
	private int coins;
	private final int coinsreset = 50;
	private final int sumacoins= 10;
	public Player() {//No podemos tener referencia a game
		this.coins = coinsreset;
		
	}
	public void usarCoins(int coinsused) 
	{
		
		this.coins=this.coins-coinsused;
	}
	
	public void reset() {
		this.coins=this.coinsreset;
	}
	
	
	public int getCoins() {
		return coins;
	}
	public void setcoins() {
		this.coins=this.coins+this.sumacoins;
	}

}
